//! Auto-link candidate discovery, threshold logic, and batch operations.
//!
//! Provides embedding-similarity-based auto-linking for newly inserted
//! memories, with model-specific thresholds, tag-aware adjustment, and
//! hub prevention via link caps.

use std::sync::Arc;

use crate::cache::CacheManager;
use crate::graph::SharedGraph;
use crate::graph::structure::RelationshipGraph;
use crate::model::{DecayPhase, EdgeType, MemoryId, NamespaceId};
use crate::search::{EntityIndex, FlatVectorIndex, SearchFilter, VectorIndex};
use crate::storage::engine::RedbStorageEngine;
use crate::storage::{PersistedEdge, StorageEngine};

// ═══════════════════════════════════════════════════════════════════════
// Constants
// ═══════════════════════════════════════════════════════════════════════

/// Hard floor for similarity threshold. No embedding model produces
/// meaningful "related" signals below this.
pub const THRESHOLD_HARD_FLOOR: f32 = 0.40;

/// Maximum auto-created associative edges per memory.
/// Prevents hub nodes and quadratic edge growth.
pub const DEFAULT_MAX_LINKS: usize = 15;

/// Threshold reduction when new memory shares tags with a candidate.
/// Applied per-pair, capped at 0.05 regardless of shared tag count.
pub const TAG_THRESHOLD_ADJUSTMENT: f32 = 0.05;

// ═══════════════════════════════════════════════════════════════════════
// AutoLinkCandidate
// ═══════════════════════════════════════════════════════════════════════

/// A candidate for auto-linking, returned by the discovery step.
#[derive(Debug, Clone)]
pub struct AutoLinkCandidate {
    /// The candidate memory's ID.
    pub memory_id: MemoryId,
    /// Cosine similarity between the new memory and this candidate.
    pub similarity: f32,
    /// Whether tag adjustment was applied to the threshold.
    pub shared_tags: bool,
}

// ═══════════════════════════════════════════════════════════════════════
// auto_link
// ═══════════════════════════════════════════════════════════════════════

/// Discover and create auto-links for a newly inserted memory.
///
/// This function performs both phases of auto-linking:
/// 1. **Discovery**: find candidate memories above the similarity threshold
/// 2. **Filtering**: exclude candidates that already have edges, apply cap
///
/// The caller is responsible for persisting the returned edges to `edges.db`
/// and inserting them into the in-memory graph.
///
/// # Arguments
/// - `new_memory`: the newly inserted memory's ID
/// - `candidates`: pre-computed (memory_id, similarity) pairs from the
///   vector search buffer. The caller runs the similarity search against
///   `EmbeddingBuffer` and passes results here. This separation keeps
///   autolink.rs decoupled from the vector storage layer.
/// - `threshold`: namespace-configured similarity threshold
/// - `new_tags`: tags on the new memory (for tag-aware threshold adjustment)
/// - `existing_tags`: function to retrieve tags for a candidate memory
///   (avoids coupling to the metadata storage layer)
/// - `max_links`: cap on auto-created edges (default: 15)
/// - `graph`: reference to check for existing edges
///
/// # Returns
/// Edges to create, sorted by descending similarity. Each tuple is
/// (target_memory_id, EdgeType::Associative). The weight of each edge
/// should be set to the similarity score.
pub fn auto_link(
    new_memory: MemoryId,
    candidates: &[(MemoryId, f32)],
    threshold: f32,
    new_tags: &[String],
    existing_tags: &dyn Fn(&MemoryId) -> Vec<String>,
    max_links: usize,
    graph: &RelationshipGraph,
) -> Vec<(MemoryId, EdgeType)> {
    // Enforce hard floor
    let effective_threshold = threshold.max(THRESHOLD_HARD_FLOOR);

    let mut accepted: Vec<AutoLinkCandidate> = Vec::new();

    for &(ref candidate_id, similarity) in candidates {
        // Skip self
        if *candidate_id == new_memory {
            continue;
        }

        // Skip if any edge already exists between new_memory and candidate
        if graph.contains(candidate_id) && graph.contains(&new_memory) {
            if graph.has_typed_edge_between_ids(&new_memory, candidate_id, EdgeType::Associative) {
                continue;
            }
        }

        // Tag-aware threshold adjustment
        let candidate_tags = existing_tags(candidate_id);
        let shares_tags = new_tags.iter().any(|t| candidate_tags.contains(t));
        let adjusted_threshold = if shares_tags {
            (effective_threshold - TAG_THRESHOLD_ADJUSTMENT).max(THRESHOLD_HARD_FLOOR)
        } else {
            effective_threshold
        };

        if similarity >= adjusted_threshold {
            accepted.push(AutoLinkCandidate {
                memory_id: *candidate_id,
                similarity,
                shared_tags: shares_tags,
            });
        }
    }

    // Sort by similarity descending, take top max_links
    accepted.sort_by(|a, b| {
        b.similarity
            .partial_cmp(&a.similarity)
            .unwrap_or(std::cmp::Ordering::Equal)
    });
    accepted.truncate(max_links);

    accepted
        .into_iter()
        .map(|c| (c.memory_id, EdgeType::Associative))
        .collect()
}

// ═══════════════════════════════════════════════════════════════════════
// AutoLinkError
// ═══════════════════════════════════════════════════════════════════════

/// Errors that can occur during the auto-link orchestration.
#[derive(Debug, thiserror::Error)]
pub enum AutoLinkError {
    /// Vector similarity search failed.
    #[error("vector search failed: {0}")]
    VectorSearch(String),
    /// Graph mutation error (e.g., missing node or duplicate edge).
    #[error("graph error: {0}")]
    Graph(#[from] crate::graph::GraphError),
    /// Storage persistence error.
    #[error("storage error: {0}")]
    Storage(String),
    /// A shared lock was poisoned by a panicking thread.
    #[error("lock poisoned: {0}")]
    LockPoisoned(String),
}

// ═══════════════════════════════════════════════════════════════════════
// persist_edges — shared helper for edge persistence + graph insertion
// ═══════════════════════════════════════════════════════════════════════

/// Plan under graph ownership, commit canonical effects, then publish.
/// ponytail: cloning costs O(V+E); replace with a nonmutating planner if measured.
pub(crate) async fn persist_edges(
    _new_memory_id: MemoryId,
    persisted_edges: &[PersistedEdge],
    graph: &SharedGraph,
    storage: &Arc<std::sync::RwLock<RedbStorageEngine>>,
    cache: &Arc<CacheManager>,
) -> Result<usize, AutoLinkError> {
    if persisted_edges.is_empty() {
        return Ok(0);
    }
    let live = graph.clone().write_owned().await;
    let mut planned = (*live).clone();
    let mut accepted = Vec::new();
    for pe in persisted_edges {
        match planned.add_edge(
            pe.source,
            pe.target,
            pe.edge_type,
            pe.weight,
            pe.auto_created,
        ) {
            Ok(key) => {
                planned.edges[key].created_at = pe.created_at as i64;
                accepted.push(pe.clone());
            }
            Err(
                crate::graph::GraphError::EdgeExists(_, _)
                | crate::graph::GraphError::MemoryNotFound(_),
            ) => {}
            Err(e) => return Err(AutoLinkError::Graph(e)),
        }
    }
    if accepted.is_empty() {
        return Ok(0);
    }
    publish_edge_plan(live, planned, accepted, storage, cache).await
}

pub(crate) async fn publish_edge_plan(
    mut live: tokio::sync::OwnedRwLockWriteGuard<crate::graph::RelationshipGraph>,
    planned: crate::graph::RelationshipGraph,
    edges: Vec<PersistedEdge>,
    storage: &Arc<std::sync::RwLock<RedbStorageEngine>>,
    cache: &Arc<CacheManager>,
) -> Result<usize, AutoLinkError> {
    let storage_commit = storage.clone();
    let (result, live) = tokio::task::spawn_blocking(move || {
        // Shared lifecycle order: graph -> storage -> metadata publication.
        let store = storage_commit
            .write()
            .map_err(|e| AutoLinkError::LockPoisoned(e.to_string()))?;
        let result = store
            .put_edges_with_effects(&edges)
            .map_err(|e| AutoLinkError::Storage(e.to_string()))?
            .ok_or_else(|| AutoLinkError::Storage("empty edge plan".into()))?;
        crate::storage::metadata::effects::crash_point("before_graph_publish");
        *live = planned;
        Ok::<_, AutoLinkError>((result, live))
    })
    .await
    .map_err(|e| AutoLinkError::Storage(e.to_string()))??;
    // Keep graph ownership across cache publication, preventing a later writer
    // from publishing a newer absolute count before this one.
    for (id, count) in &result.peer_counts {
        cache.update_edge_count(*id, *count).await;
    }
    let created = result.edges_put;
    let storage_ack = storage.clone();
    tokio::task::spawn_blocking(move || {
        let store = storage_ack
            .write()
            .map_err(|e| AutoLinkError::LockPoisoned(e.to_string()))?;
        crate::storage::metadata::effects::crash_point("before_derived_ack");
        store
            .acknowledge_graph_effects(result.receipt.operation_id)
            .map_err(|e| AutoLinkError::Storage(e.to_string()))?;
        drop(live);
        Ok::<_, AutoLinkError>(())
    })
    .await
    .map_err(|e| AutoLinkError::Storage(e.to_string()))??;
    Ok(created)
}

// ═══════════════════════════════════════════════════════════════════════
// perform_autolink
// ═══════════════════════════════════════════════════════════════════════

/// Orchestrate auto-link discovery and persistence for a newly stored memory.
///
/// This function:
/// 1. Searches the vector index for similar candidates
/// 2. Calls `auto_link()` to filter and rank them
/// 3. Persists edges to edges.db via `batch_add_edges()`
/// 4. Inserts edges into the in-memory graph
/// 5. Updates `edge_count` on the new memory's DiskRecord
///
/// Returns the number of edges created.
///
/// # Lock ordering
///
/// The graph `RwLock` is acquired twice:
/// - First as a **read** lock for `auto_link()` candidate discovery
/// - Then as a **write** lock for edge insertion
///
/// The read lock is explicitly dropped before the write lock is acquired
/// to prevent deadlocks.
pub async fn perform_autolink(
    new_memory_id: MemoryId,
    namespace_id: NamespaceId,
    embedding: &[f32],
    tags: &[String],
    threshold: f32,
    max_links: usize,
    vector_index: &Arc<tokio::sync::RwLock<FlatVectorIndex>>,
    graph: &SharedGraph,
    storage: &Arc<std::sync::RwLock<RedbStorageEngine>>,
    cache: &Arc<CacheManager>,
) -> Result<usize, AutoLinkError> {
    // Step 1: Search vector index for top candidates.
    let search_limit = max_links * 2 + 1;
    let candidates: Vec<(MemoryId, f32)> = {
        let index = vector_index.read().await;
        let filter = SearchFilter {
            namespace_id: Some(namespace_id),
            decay_phases: Some(vec![DecayPhase::Full.as_u8(), DecayPhase::Summary.as_u8()]),
            ..SearchFilter::default()
        };
        let results = index
            .search(embedding, search_limit, &filter)
            .map_err(|e| AutoLinkError::VectorSearch(e.to_string()))?;
        results.into_iter().map(|r| (r.id, r.score)).collect()
    };

    if candidates.is_empty() {
        return Ok(0);
    }

    // Step 2: Build tag lookup closure from cache.
    // Collect candidate tags up front to avoid holding locks in the closure.
    let candidate_ids: Vec<MemoryId> = candidates.iter().map(|(id, _)| *id).collect();
    let mut candidate_tags_map = std::collections::HashMap::new();
    for cid in &candidate_ids {
        if let Some(cached) = cache.get(*cid).await {
            candidate_tags_map.insert(
                *cid,
                cached
                    .tags
                    .iter()
                    .map(|t| t.to_string())
                    .collect::<Vec<_>>(),
            );
        }
    }

    let tag_lookup =
        |id: &MemoryId| -> Vec<String> { candidate_tags_map.get(id).cloned().unwrap_or_default() };

    // Step 3: Read-lock graph for auto_link() discovery, then DROP the lock.
    let edges_to_create = {
        let graph_r = graph.read().await;
        auto_link(
            new_memory_id,
            &candidates,
            threshold,
            tags,
            &tag_lookup,
            max_links,
            &graph_r,
        )
    }; // graph read lock dropped here

    if edges_to_create.is_empty() {
        return Ok(0);
    }

    // Step 4: Build PersistedEdge records with similarity scores as weights.
    let now_ms = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64;

    // Build a lookup for candidate similarity scores.
    let similarity_map: std::collections::HashMap<MemoryId, f32> =
        candidates.iter().map(|(id, score)| (*id, *score)).collect();

    let persisted_edges: Vec<PersistedEdge> = edges_to_create
        .iter()
        .map(|(target_id, edge_type)| PersistedEdge {
            source: new_memory_id,
            target: *target_id,
            edge_type: *edge_type,
            weight: similarity_map.get(target_id).copied().unwrap_or(0.0),
            auto_created: true,
            created_at: now_ms,
        })
        .collect();

    // Steps 5-7: Persist edges, insert into graph, update edge count.
    persist_edges(new_memory_id, &persisted_edges, graph, storage, cache).await
}

// ═══════════════════════════════════════════════════════════════════════
// perform_entity_link
// ═══════════════════════════════════════════════════════════════════════

/// Create Entity edges between a newly stored memory and other memories
/// sharing named entities (e.g., both mention "Caroline").
///
/// Edge weight = Jaccard similarity (shared_count / union_count).
pub async fn perform_entity_link(
    new_memory_id: MemoryId,
    namespace_id: NamespaceId,
    entities: &[String],
    max_entity_links: usize,
    entity_index: &tokio::sync::RwLock<EntityIndex>,
    graph: &SharedGraph,
    storage: &Arc<std::sync::RwLock<RedbStorageEngine>>,
    cache: &Arc<CacheManager>,
) -> Result<usize, AutoLinkError> {
    if entities.is_empty() {
        return Ok(0);
    }

    let candidates = {
        let idx = entity_index.read().await;
        idx.find_by_entities(namespace_id, entities, new_memory_id)
    };

    if candidates.is_empty() {
        return Ok(0);
    }

    // Postings propose IDs only: namespace and deletion state must be checked
    // canonically before the cap, even when caches/indexes are stale.
    let storage_for_read = storage.clone();
    let candidates = tokio::task::spawn_blocking(move || {
        let storage = storage_for_read
            .read()
            .map_err(|e| AutoLinkError::LockPoisoned(e.to_string()))?;
        let source = storage
            .get_record(new_memory_id)
            .map_err(|e| AutoLinkError::Storage(e.to_string()))?;
        let live_in_scope = |r: &crate::model::DiskRecord| {
            r.namespace_id == namespace_id.get() && r.phase != DecayPhase::Tombstone
        };
        if source.as_ref().is_none_or(|r| !live_in_scope(r)) {
            return Ok::<_, AutoLinkError>(Vec::new());
        }
        let mut eligible = Vec::new();
        for (id, shared) in candidates {
            if storage
                .get_record(id)
                .map_err(|e| AutoLinkError::Storage(e.to_string()))?
                .as_ref()
                .is_some_and(&live_in_scope)
            {
                eligible.push((id, shared));
            }
        }
        eligible.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
        Ok(eligible)
    })
    .await
    .map_err(|e| AutoLinkError::Storage(format!("blocking task join error: {e}")))??;

    // Keep legacy scoring until structured entity persistence supports all
    // accepted names. Plain Tag parsing currently loses multiword/Unicode names;
    // treating those persisted tags as complete would silently remove links.
    let key_count = |names: &[String]| {
        names
            .iter()
            .flat_map(|name| crate::search::canonicalize_entity(name))
            .collect::<std::collections::HashSet<_>>()
            .len()
    };
    let source_count = key_count(entities);
    let mut candidate_entity_counts = std::collections::HashMap::new();
    for (id, _) in &candidates {
        if let Some(cached) = cache.get(*id).await {
            candidate_entity_counts.insert(*id, key_count(&cached.entities));
        }
    }
    let edges_to_create: Vec<(MemoryId, f32)> = {
        let graph_r = graph.read().await;
        candidates
            .iter()
            .filter(|(cid, _)| {
                !graph_r.has_typed_edge_between_ids(&new_memory_id, cid, EdgeType::Entity)
            })
            .take(max_entity_links)
            .map(|(cid, shared)| {
                // Postings may retain accepted names missing from legacy tags.
                // Count normalized keys consistently and bound stale cache counts
                // by observed overlap, avoiding subtraction underflow.
                let candidate_count = candidate_entity_counts
                    .get(cid)
                    .copied()
                    .unwrap_or(*shared)
                    .max(*shared);
                let union = source_count.max(*shared) + candidate_count - *shared;
                let weight = if union > 0 {
                    (*shared as f32 / union as f32).min(1.0)
                } else {
                    0.0
                };
                (*cid, weight)
            })
            .collect()
    };

    if edges_to_create.is_empty() {
        return Ok(0);
    }

    let now_ms = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64;

    let persisted_edges: Vec<PersistedEdge> = edges_to_create
        .iter()
        .map(|(target_id, weight)| PersistedEdge {
            source: new_memory_id,
            target: *target_id,
            edge_type: EdgeType::Entity,
            weight: *weight,
            auto_created: true,
            created_at: now_ms,
        })
        .collect();

    persist_edges(new_memory_id, &persisted_edges, graph, storage, cache).await
}

// ═══════════════════════════════════════════════════════════════════════
// perform_temporal_link
// ═══════════════════════════════════════════════════════════════════════

/// Create Temporal edges between a newly stored memory and other memories
/// created within a time window.
///
/// `recent_memories` must be sorted by timestamp ascending. Edge weight
/// = 1.0 - (time_delta / window), floored at 0.05.
pub async fn perform_temporal_link(
    new_memory_id: MemoryId,
    _namespace_id: NamespaceId,
    created_at_ms: i64,
    temporal_window_ms: u64,
    max_temporal_links: usize,
    recent_memories: &[(MemoryId, i64)],
    graph: &SharedGraph,
    storage: &Arc<std::sync::RwLock<RedbStorageEngine>>,
    cache: &Arc<CacheManager>,
) -> Result<usize, AutoLinkError> {
    if temporal_window_ms == 0 || recent_memories.is_empty() {
        return Ok(0);
    }

    let window = temporal_window_ms as i64;

    // Find memories within the time window.
    let candidates: Vec<(MemoryId, f32)> = recent_memories
        .iter()
        .filter(|(mid, _)| *mid != new_memory_id)
        .filter_map(|(mid, ts)| {
            let delta = (created_at_ms - ts).abs();
            if delta <= window {
                let weight = (1.0 - delta as f32 / window as f32).max(0.05);
                Some((*mid, weight))
            } else {
                None
            }
        })
        .collect();

    if candidates.is_empty() {
        return Ok(0);
    }

    // Read-lock graph to filter out existing edges.
    let edges_to_create: Vec<(MemoryId, f32)> = {
        let graph_r = graph.read().await;
        candidates
            .iter()
            .filter(|(cid, _)| {
                !graph_r.has_typed_edge_between_ids(&new_memory_id, cid, EdgeType::Temporal)
            })
            .take(max_temporal_links)
            .cloned()
            .collect()
    };

    if edges_to_create.is_empty() {
        return Ok(0);
    }

    let now_ms = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64;

    let persisted_edges: Vec<PersistedEdge> = edges_to_create
        .iter()
        .map(|(target_id, weight)| PersistedEdge {
            source: new_memory_id,
            target: *target_id,
            edge_type: EdgeType::Temporal,
            weight: *weight,
            auto_created: true,
            created_at: now_ms,
        })
        .collect();

    persist_edges(new_memory_id, &persisted_edges, graph, storage, cache).await
}

#[cfg(test)]
mod entity_scope_tests {
    use super::*;
    use crate::test_support::Fixture;

    #[tokio::test]
    async fn entity_links_filter_foreign_and_removed_postings_before_cap_without_cache() {
        let f = Fixture::new();
        let ns = NamespaceId::new(1);
        let foreign_ns = f.create_namespace("foreign");
        let source = f
            .insert_memory_in(ns, &["entity/alice", "entity/bob"])
            .await;
        let local = f
            .insert_memory_in(ns, &["entity/alice", "entity/carol"])
            .await;
        let foreign = f
            .insert_memory_in(foreign_ns, &["entity/alice", "entity/bob"])
            .await;
        let removed = f
            .insert_memory_in(ns, &["entity/alice", "entity/bob"])
            .await;
        f.tombstone(removed);
        {
            let mut index = f.entity_index.write().await;
            index.add(ns, local, &["alice".into()]);
            for id in [foreign, removed, MemoryId::new()] {
                index.add(ns, id, &["alice".into(), "bob".into()]);
            }
        }
        let count = perform_entity_link(
            source,
            ns,
            &["alice".into(), "bob".into()],
            1,
            &f.entity_index,
            &f.graph,
            &f.storage,
            &f.cache,
        )
        .await
        .unwrap();
        assert_eq!(count, 1);
        let edges = f.storage.read().unwrap().load_all_edges().unwrap();
        assert_eq!(edges.len(), 1);
        assert_eq!(edges[0].target, local);
        assert!((edges[0].weight - 0.5).abs() < 1e-6);
        assert!(
            f.graph
                .read()
                .await
                .has_typed_edge_between_ids(&source, &local, EdgeType::Entity)
        );
    }

    #[tokio::test]
    async fn accepted_multiword_unicode_and_possessive_names_still_link() {
        use crate::mcp::bridge::{StorageEngine as _, StoreInput};
        for name in ["John Smith", "José", "Alice's"] {
            let f = Fixture::new();
            let adapter = f.storage_adapter();
            let input = || StoreInput {
                summary: "accepted structured name".into(),
                full_text: None,
                tags: vec![],
                entities: vec![name.into()],
                topics: vec![],
                emotions: vec![],
                namespace: "default".into(),
                embedding: Some(vec![1.0, 0.0, 0.0, 0.0]),
                initial_stability: None,
                parent_id: None,
                supersedes: None,
                check_duplicates: None,
            };
            adapter.store_memory(input()).await.unwrap();
            adapter.store_memory(input()).await.unwrap();
            let edges = f.persisted_edges();
            let entity_edges: Vec<_> = edges
                .iter()
                .filter(|e| e.edge_type == EdgeType::Entity)
                .collect();
            assert_eq!(entity_edges.len(), 1, "{name}");
            assert!(entity_edges[0].weight.is_finite());
            assert!((0.0..=1.0).contains(&entity_edges[0].weight));
        }
    }

    #[tokio::test]
    async fn entity_links_reject_wrong_source_scope_and_resolve_ties_by_uuid() {
        let f = Fixture::new();
        let ns = NamespaceId::new(1);
        let other = f.create_namespace("other");
        let source = f.insert_memory_in(ns, &["entity/alice"]).await;
        let a = f.insert_memory_in(ns, &["entity/alice"]).await;
        let b = f.insert_memory_in(ns, &["entity/alice"]).await;
        {
            let mut index = f.entity_index.write().await;
            index.add(ns, b, &["alice".into()]);
            index.add(ns, a, &["alice".into()]);
        }
        assert_eq!(
            perform_entity_link(
                source,
                other,
                &["alice".into()],
                1,
                &f.entity_index,
                &f.graph,
                &f.storage,
                &f.cache
            )
            .await
            .unwrap(),
            0
        );
        assert!(
            f.storage
                .read()
                .unwrap()
                .load_all_edges()
                .unwrap()
                .is_empty()
        );
        assert_eq!(
            perform_entity_link(
                source,
                ns,
                &["alice".into()],
                1,
                &f.entity_index,
                &f.graph,
                &f.storage,
                &f.cache
            )
            .await
            .unwrap(),
            1
        );
        let edges = f.storage.read().unwrap().load_all_edges().unwrap();
        assert_eq!(edges[0].target, a.min(b));
        assert_eq!(edges[0].weight, 1.0);
        f.tombstone(source);
        assert_eq!(
            perform_entity_link(
                source,
                ns,
                &["alice".into()],
                1,
                &f.entity_index,
                &f.graph,
                &f.storage,
                &f.cache
            )
            .await
            .unwrap(),
            0
        );
        assert_eq!(f.storage.read().unwrap().load_all_edges().unwrap().len(), 1);
    }
}
