//! Integration-only probes: actual ledger/effects writers, never synthesized rows.
use super::*;
use crate::backup::{RestoreOptions, restore_from_backup, run_backup};
use crate::config::RecalldConfig;
use crate::model::schema::{
    EmbeddingBinding, EmbeddingProfile, Normalization, PreprocessingIdentity, ProviderKind,
};
use crate::model::{NamespaceConfig, NamespaceId};
use crate::storage::control::{self, MutationContext, MutationScope};
use crate::storage::schema_migration::{
    MigrationOptions, ProfileAttestationInput, inspect_schema, migrate_schema,
};
use crate::test_support::MemorySpec;

use crate::model::{AccessKind, EdgeType};
use crate::storage::metadata::{effects, removal_ledger};
use crate::storage::{PersistedEdge, RedbStorageEngine, StorageEngine};
use crate::test_support::Fixture;
use redb::TableDefinition;
use std::collections::BTreeMap;

fn files(path: &Path) -> BTreeMap<std::path::PathBuf, Vec<u8>> {
    fn visit(base: &Path, path: &Path, result: &mut BTreeMap<std::path::PathBuf, Vec<u8>>) {
        for entry in std::fs::read_dir(path).unwrap() {
            let entry = entry.unwrap();
            let child = entry.path();
            if entry.file_type().unwrap().is_dir() {
                visit(base, &child, result);
            } else if child.extension().is_some_and(|e| e == "dat")
                || matches!(entry.file_name().to_str(), Some("meta.db" | "edges.db"))
            {
                result.insert(
                    child.strip_prefix(base).unwrap().to_path_buf(),
                    std::fs::read(child).unwrap(),
                );
            }
        }
    }
    let mut result = BTreeMap::new();
    visit(path, path, &mut result);
    result
}

fn byte_rows(
    read: &redb::ReadTransaction,
    table: TableDefinition<&[u8], &[u8]>,
) -> Vec<(Vec<u8>, Vec<u8>)> {
    read.open_table(table)
        .unwrap()
        .iter()
        .unwrap()
        .map(|r| {
            let (k, v) = r.unwrap();
            (k.value().to_vec(), v.value().to_vec())
        })
        .collect()
}

fn text_rows(
    read: &redb::ReadTransaction,
    table: TableDefinition<&str, &[u8]>,
) -> Vec<(String, Vec<u8>)> {
    read.open_table(table)
        .unwrap()
        .iter()
        .unwrap()
        .map(|r| {
            let (k, v) = r.unwrap();
            (k.value().to_owned(), v.value().to_vec())
        })
        .collect()
}

fn edge(a: crate::model::MemoryId, b: crate::model::MemoryId) -> PersistedEdge {
    PersistedEdge {
        source: a,
        target: b,
        edge_type: EdgeType::Associative,
        weight: 0.375,
        auto_created: false,
        created_at: 123,
    }
}

fn context(store: uuid::Uuid, scope: MutationScope, key: &str) -> MutationContext {
    MutationContext {
        store_id: Some(store),
        scope,
        idempotency_key: Some(key.into()),
        expected_generation: None,
        contract_version: 1,
    }
}

fn assert_relations(source: &Path, target: &Path, include_effects: bool) {
    let (_s, s) = crate::storage::validation::inspect_database(&source.join("meta.db")).unwrap();
    let (_t, t) = crate::storage::validation::inspect_database(&target.join("meta.db")).unwrap();
    let sr = s.begin_read().unwrap();
    let tr = t.begin_read().unwrap();
    for table in [control::RECEIPTS, control::KEYS, removal_ledger::LEDGER] {
        assert_eq!(
            byte_rows(&sr, table),
            byte_rows(&tr, table),
            "{}",
            table.name()
        );
    }
    if include_effects {
        assert_eq!(
            byte_rows(&sr, effects::EFFECTS),
            byte_rows(&tr, effects::EFFECTS)
        );
        assert_eq!(
            text_rows(&sr, removal_ledger::STATE),
            text_rows(&tr, removal_ledger::STATE)
        );
    }
    // A restore forks active ledger coverage; the original state is retained in
    // lineage. A same-lineage logical import must preserve it byte-for-byte.
    assert_eq!(
        text_rows(&sr, crate::storage::canonical_schema::SCHEMA),
        text_rows(&tr, crate::storage::canonical_schema::SCHEMA)
    );
}

#[tokio::test]
async fn combined_export_preserves_real_ledger_effects_catalog_observation_and_fork_receipts() {
    let fixture = Fixture::new();
    let ns = NamespaceId::new(1);
    let a = fixture
        .insert_memory_with(MemorySpec {
            embedding: Some(&[1., -0., 0., 0.]),
            summary: "retained résumé",
            tags: &["entity/john-smith"],
            ..MemorySpec::new(ns)
        })
        .await;
    let b = fixture
        .insert_memory_with(MemorySpec {
            embedding: Some(&[0., 1., 0., 0.]),
            ..MemorySpec::new(ns)
        })
        .await;
    let (deleted, catalog_receipt, observation_receipt, deletion_receipt, retained) = {
        let mut engine = fixture.storage.write().unwrap();
        let store = engine.control_state().unwrap().store_id;
        let mut config = NamespaceConfig::default_namespace(123);
        config.name = "unknown-provenance".into();
        config.embedding_dim = 4;
        let catalog = engine
            .create_namespace_with_receipt(
                &context(store, MutationScope::Catalog, "catalog-evidence"),
                &config,
            )
            .unwrap();
        let observation = engine
            .meta_store()
            .record_exposure_batch(
                &context(store, MutationScope::Namespace(ns), "observed-evidence"),
                &[(a, AccessKind::DirectRetrieval)],
                1234,
            )
            .unwrap()
            .unwrap();
        let mut record = engine.get_record(a).unwrap().unwrap();
        let deleted = crate::model::MemoryId::new();
        record.id = *deleted.as_bytes();
        record.summary = "FORGOTTEN-COMBINED-93f4".into();
        engine
            .insert_memory(
                deleted,
                ns,
                &mut record,
                &[1., 0., 0., 0.],
                Some("FORGOTTEN-COMBINED-93f4"),
            )
            .unwrap();
        // Retained text and exact f32 bits pass through real canonical insertion.
        let retained = crate::model::MemoryId::new();
        record.id = *retained.as_bytes();
        record.summary = "retained Unicode José".into();
        record.text_offset = 0;
        record.text_length = 0;
        engine
            .insert_memory(
                retained,
                ns,
                &mut record,
                &[0., 0., 1., -0.],
                Some("retained text José 🦀"),
            )
            .unwrap();
        let put = engine
            .put_edges_with_effects(&[edge(deleted, a)])
            .unwrap()
            .unwrap();
        engine
            .acknowledge_graph_effects(put.receipt.operation_id)
            .unwrap();
        let deletion = engine
            .delete_memory_with_edges(deleted, &[edge(a, b)])
            .unwrap()
            .unwrap();
        let effects = engine.meta_store().pending_effects().unwrap();
        assert_eq!(effects.len(), 1);
        assert!(effects[0].canonical_applied);
        let ledger = engine.meta_store().removal_ledger_export().unwrap();
        assert!(
            ledger
                .entries
                .iter()
                .any(|e| e.memory_uuid == deleted.into_inner()
                    && e.operation_id == deletion.receipt.operation_id
                    && e.removed_fields_mask == removal_ledger::ALL)
        );
        engine.sync().unwrap();
        (deleted, catalog, observation, deletion.receipt, retained)
    };
    let legacy = fixture.close();
    let before_legacy = files(legacy.path());
    let root = tempfile::tempdir().unwrap();
    let source = root.path().join("schema");
    let source_ref = inspect_schema(legacy.path())
        .unwrap()
        .control
        .generation_ref();
    migrate_schema(
        legacy.path(),
        &source,
        &MigrationOptions {
            expected_source: source_ref,
            migration_now: 12345,
            attestations: vec![ProfileAttestationInput {
                namespace_id: ns,
                namespace_name: "default".into(),
                descriptor: EmbeddingProfile {
                    identity_version: 1,
                    provider_kind: ProviderKind::Passthrough,
                    model_id: "explicit-fixture-model".into(),
                    model_revision: Some("1".into()),
                    dimension: 4,
                    document_preprocessing: PreprocessingIdentity {
                        version: "recalld-document-v1".into(),
                        prefix: "".into(),
                    },
                    query_preprocessing: PreprocessingIdentity {
                        version: "recalld-query-v1".into(),
                        prefix: "".into(),
                    },
                    normalization: Normalization::L2UnitV1,
                },
            }],
        },
    )
    .unwrap();
    assert_eq!(files(legacy.path()), before_legacy);
    let before = files(&source);
    let export = root.path().join("export.jsonl");
    let expected = export_store(&source, &export).unwrap();
    assert_eq!(expected.records, 3);
    let serialized = std::fs::read(&export).unwrap();
    assert!(
        !serialized
            .windows(b"FORGOTTEN-COMBINED-93f4".len())
            .any(|w| w == b"FORGOTTEN-COMBINED-93f4")
    );
    let target = root.path().join("imported");
    assert_eq!(import_store(&export, &target).unwrap(), expected);
    assert_relations(&source, &target, true);
    assert_eq!(
        inspect_schema(&source).unwrap().control,
        inspect_schema(&target).unwrap().control
    );
    let reexport = export_store(&target, &root.path().join("reexport.jsonl")).unwrap();
    assert_eq!(reexport.logical_sha256, expected.logical_sha256);
    {
        let snapshot = OfflineSnapshot::open(&target).unwrap();
        assert!(snapshot.record(deleted).unwrap().is_none());
        assert_eq!(
            snapshot
                .record(retained)
                .unwrap()
                .unwrap()
                .full_text
                .as_deref(),
            Some("retained text José 🦀")
        );
        let vector = snapshot.record(a).unwrap().unwrap().embedding.unwrap();
        assert_eq!(
            vector.iter().map(|f| f.to_bits()).collect::<Vec<_>>(),
            [1f32.to_bits(), (-0f32).to_bits(), 0, 0]
        );
        assert!(matches!(
            snapshot.namespaces()[0]
                .schema
                .as_ref()
                .unwrap()
                .embedding_binding,
            EmbeddingBinding::Bound { .. }
        ));
        assert!(matches!(
            snapshot.namespaces()[1]
                .schema
                .as_ref()
                .unwrap()
                .embedding_binding,
            EmbeddingBinding::UnknownLegacy { .. }
        ));
    }
    assert_eq!(files(&source), before);
    for data in files(&target).values() {
        assert!(
            !data
                .windows(b"FORGOTTEN-COMBINED-93f4".len())
                .any(|w| w == b"FORGOTTEN-COMBINED-93f4")
        );
    }

    // Actual ManifestV2 backup -> production historical fork consumes applied
    // derived work, retaining original source/publication evidence and receipts.
    let archive = root.path().join("snapshot.zip");
    run_backup(&RecalldConfig::default(), &archive, Some(&source), false)
        .await
        .unwrap();
    let historical = root.path().join("historical");
    restore_from_backup(RestoreOptions {
        backup_path: archive,
        data_dir: historical.clone(),
        force: true,
        no_stop_daemon: true,
        historical: true,
    })
    .await
    .unwrap();
    let fork = inspect_schema(&historical).unwrap();
    assert_ne!(fork.control.store_id, expected.source.store_id);
    assert_eq!(fork.schema, inspect_schema(&source).unwrap().schema);
    assert_relations(&source, &historical, false);
    let (_copy, db) =
        crate::storage::validation::inspect_database(&historical.join("meta.db")).unwrap();
    let read = db.begin_read().unwrap();
    assert!(effects::validate_existing(&read).unwrap().is_empty());
    let ancestry = crate::storage::lineage::read_lineage(&read, &fork.control)
        .unwrap()
        .unwrap();
    assert_eq!(ancestry.source_snapshot, expected.source);
    let (_source_copy, source_db) =
        crate::storage::validation::inspect_database(&source.join("meta.db")).unwrap();
    let source_read = source_db.begin_read().unwrap();
    let source_control = control::validate_existing(&source_read).unwrap().unwrap();
    let mut original_coverage = removal_ledger::read_export(&source_read, Some(&source_control))
        .unwrap()
        .unwrap()
        .state;
    // Restore deliberately downgrades pre-gated-writer coverage rather than
    // blessing the original fixture's creation marker as a complete audit.
    original_coverage.prior_history = removal_ledger::PriorHistory::Unknown;
    assert!(
        ancestry
            .ledger_sources
            .iter()
            .any(|s| s.source == expected.source && s.coverage == original_coverage)
    );
    for receipt in [&catalog_receipt, &observation_receipt, &deletion_receipt] {
        let scope = if receipt.operation_id == catalog_receipt.operation_id {
            MutationScope::Catalog
        } else {
            MutationScope::Namespace(ns)
        };
        let key = control::scoped_key(
            expected.source.store_id,
            scope,
            receipt.operation_id.as_bytes(),
        );
        assert_eq!(
            control::validate_receipt(
                read.open_table(control::RECEIPTS)
                    .unwrap()
                    .get(key.as_slice())
                    .unwrap()
                    .unwrap()
                    .value()
            )
            .unwrap()
            .receipt,
            *receipt
        );
    }
    let historic_export = root.path().join("historical.jsonl");
    let historical_before = files(&historical);
    let historical_summary = export_store(&historical, &historic_export).unwrap();
    let historical_copy = root.path().join("historical-imported");
    assert_eq!(
        import_store(&historic_export, &historical_copy).unwrap(),
        historical_summary
    );
    assert_relations(&historical, &historical_copy, true);
    assert_eq!(
        inspect_schema(&historical_copy).unwrap().control,
        fork.control
    );
    let again = export_store(
        &historical_copy,
        &root.path().join("historical-again.jsonl"),
    )
    .unwrap();
    assert_eq!(again.logical_sha256, historical_summary.logical_sha256);
    assert_eq!(files(&historical), historical_before);
    assert_eq!(files(&source), before);
    assert_eq!(files(legacy.path()), before_legacy);
    assert!(RedbStorageEngine::open(&historical_copy).is_err());
    assert!(RedbStorageEngine::open(&target).is_err());
}

#[tokio::test]
async fn combined_export_rejects_actual_unapplied_effects_without_mutation() {
    let fixture = Fixture::new();
    let removed = fixture.insert_memory().await;
    let peer = fixture.insert_memory().await;
    {
        let mut engine = fixture.storage.write().unwrap();
        let put = engine
            .put_edges_with_effects(&[edge(removed, peer)])
            .unwrap()
            .unwrap();
        engine
            .acknowledge_graph_effects(put.receipt.operation_id)
            .unwrap();
        engine
            .meta_store()
            .fail_effect_application
            .store(true, std::sync::atomic::Ordering::SeqCst);
        assert!(matches!(
            engine.delete_memory_with_edges(removed, &[]),
            Err(StorageError::CommittedEffectsPending { .. })
        ));
    }
    let source = fixture.close();
    let before = files(source.path());
    let output = source
        .path()
        .parent()
        .unwrap()
        .join(format!("unapplied-{}.jsonl", uuid::Uuid::new_v4()));
    let error = export_store(source.path(), &output).unwrap_err();
    assert!(
        error.to_string().contains("pending canonical effects"),
        "{error}"
    );
    assert!(!output.exists());
    assert_eq!(files(source.path()), before);
}
