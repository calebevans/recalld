//! Storage layer for Recalld.
//!
//! Provides persistent storage for memory records, embeddings, text,
//! and graph edges. The public API is defined by the `StorageEngine`
//! trait; the concrete implementation is `RedbStorageEngine`.
//!
//! # Submodules
//!
//! - `vectors` — Memory-mapped vector storage (per-namespace .dat files)
//! - `metadata` — redb-backed metadata B-tree with secondary indexes
//! - `indexes` — Phase bitmap indexes (roaring)
//! - `text` — Append-only text log with CRC32 integrity
//! - `edges` — redb-backed graph edge persistence
//! - `error` — Unified `StorageError` type
//! - `fsync` — Filesystem sync helpers for crash safety

pub mod canonical_schema;
pub mod catalog;
pub mod control;
pub mod edges;
pub mod engine;
pub mod error;
pub mod fsync;
pub mod indexes;
pub mod lifecycle_migration;
pub(crate) mod lineage;
pub mod logical_export;
pub mod metadata;
pub mod offline_snapshot;
pub(crate) mod ownership;
pub(crate) mod restore_journal;
pub mod schema_migration;
pub mod text;
pub mod text_migration;
pub(crate) mod validation;
pub mod vectors;

// ── Re-exports ──────────────────────────────────────────────────────

pub use edges::{EdgeStore, PersistedEdge, cleanup_orphaned_edges};
pub use engine::{RedbStorageEngine, StorageEngine};
pub use error::StorageError;
pub use indexes::PhaseIndex;
pub use metadata::MetadataStore;
pub use text::{CompactionResult, TextRef, TextStore, recover_text_compaction};
pub use vectors::{VectorManager, VectorStore};
