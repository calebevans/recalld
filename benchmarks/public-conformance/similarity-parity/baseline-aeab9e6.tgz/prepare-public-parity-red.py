import importlib.util,pathlib,tempfile,shutil,json,subprocess,hashlib
p=pathlib.Path('/tmp/recalld-implementation/public-similarity-checks/scripts/public-conformance.py')
s=importlib.util.spec_from_file_location('runner',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=pathlib.Path(tempfile.mkdtemp(prefix='recalld-similarity-red-',dir='/tmp'));(r/'output').mkdir();(r/'target/debug').mkdir(parents=True)
manifest,patch=m.snapshot(pathlib.Path('/tmp/recalld-implementation/public-runtime-aeab9e6'),r/'source',['tests/text_migration_cli.rs','examples/offline_eval.rs'],'aeab9e68e749e4e178576c2283a6173c11611a31')
binary=pathlib.Path('/tmp/recalld-public-conformance-zoq8mlcs/target/debug/recalld');shutil.copy2(binary,r/'target/debug/recalld')
image=json.loads(subprocess.check_output(['docker','image','inspect','recalld-ci:1.94']))[0]['Id']
command=['docker','run','--rm','--network','none','--cpus','2','--memory','4g','--memory-swap','4g','--cap-drop','ALL','--security-opt','no-new-privileges','--read-only','--tmpfs','/tmp:rw,nosuid,nodev','--mount',f'type=bind,src={r},dst=/work','--workdir','/work/source','--env','HOME=/tmp/home','--env','RUSTUP_TOOLCHAIN=1.94.1',image,'python3','scripts/public-conformance.py','--inside','--fixture-version','3']
manifest.update({'track':'public-v1-similarity-regression-red','binaryReusedFrom':str(binary),'binarySha256':m.sha(binary),'originalBuildManifest':'/tmp/recalld-public-conformance-zoq8mlcs/output/manifest.json','imageId':image,'containerCommand':command,'fixtureVersion':3,'status':'running'})
m.save(r/'output/manifest.json',manifest);print(r,flush=True)
try:
    with (r/'output/container.log').open('w') as f: subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
    manifest['status']='completed'
finally:
    manifest['outputsSha256']={str(p.relative_to(r/'output')):m.sha(p) for p in sorted((r/'output').rglob('*')) if p.is_file() and p.name!='manifest.json'}
    m.save(r/'output/manifest.json',manifest)
    print(manifest['status'],r,flush=True)
