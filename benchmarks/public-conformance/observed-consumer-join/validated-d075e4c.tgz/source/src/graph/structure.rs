//! Graph data structure: nodes, edges, keys, and the `RelationshipGraph`.
//!
//! Provides the core in-memory graph representation using `slotmap::DenseSlotMap`
//! for O(1) insert/remove/lookup with generational key safety.

use std::collections::HashMap;

use slotmap::{DenseSlotMap, new_key_type};

use crate::model::{DecayPhase, EdgeType, MemoryId, NamespaceId};

// ═══════════════════════════════════════════════════════════════════════
// Key Types
// ═══════════════════════════════════════════════════════════════════════

new_key_type! {
    /// Generational key for graph nodes. 8 bytes, Copy, Eq, Hash.
    /// Catches use-after-delete: if a node is removed and its slot
    /// reused, stale NodeKeys fail validation rather than silently
    /// resolving to the wrong node.
    pub struct NodeKey;
}

new_key_type! {
    /// Generational key for graph edges. Same properties as NodeKey.
    pub struct EdgeKey;
}

// ═══════════════════════════════════════════════════════════════════════
// GraphNode
// ═══════════════════════════════════════════════════════════════════════

/// Lightweight graph-local node. The full MemoryRecord lives in meta.db
/// and the RAM cache -- the graph stores only what traversal and
/// activation need.
#[derive(Debug, Clone)]
pub struct GraphNode {
    /// Primary key -- maps back to the full MemoryRecord in meta.db.
    pub memory_id: MemoryId,

    /// Namespace this memory belongs to. Used for scoped traversal
    /// and namespace-filtered spreading activation.
    pub namespace_id: NamespaceId,

    /// Current decay phase (Full / Summary / Ghost).
    /// Updated by decay sweeps via `update_node_state`.
    pub decay_phase: DecayPhase,

    /// Current retrievability R(t,S), cached from the last decay sweep
    /// or access event. Used by spreading activation to weight neighbor
    /// contributions (a forgotten neighbor provides no boost).
    pub strength: f32,

    /// Index into the namespace's vectors.dat flat buffer. Enables the
    /// auto-linker (CS-11) to retrieve embeddings without a meta.db
    /// round-trip.
    pub vector_slot: u32,

    /// Outgoing edge keys (this node is `source`).
    pub outgoing: Vec<EdgeKey>,

    /// Incoming edge keys (this node is `target`).
    pub incoming: Vec<EdgeKey>,
}

impl GraphNode {
    /// Total degree: outgoing + incoming edges.
    #[inline]
    pub fn degree(&self) -> usize {
        self.outgoing.len() + self.incoming.len()
    }
}

// ═══════════════════════════════════════════════════════════════════════
// GraphEdge
// ═══════════════════════════════════════════════════════════════════════

/// A typed, weighted, directed edge between two graph nodes.
#[derive(Debug, Clone)]
pub struct GraphEdge {
    /// Source node key (the "from" end).
    pub source: NodeKey,

    /// Target node key (the "to" end).
    pub target: NodeKey,

    /// Relationship type. Determines spreading activation weight
    /// and RIF competitor weight (see Spec 05 section 2.4).
    pub edge_type: EdgeType,

    /// Associative strength, 0.0-1.0. For auto-created edges this is
    /// the cosine similarity at creation time. Manual edges default
    /// to 1.0.
    pub weight: f32,

    /// True if this edge was created by the auto-linker (CS-11),
    /// false if manually created via the API.
    pub auto_created: bool,

    /// Milliseconds since Unix epoch when this edge was created.
    pub created_at: i64,
}

// ═══════════════════════════════════════════════════════════════════════
// Traversal Types
// ═══════════════════════════════════════════════════════════════════════

/// Direction filter for BFS traversal.
#[derive(Debug, Clone, Default)]
pub enum TraversalDirection {
    /// Follow both outgoing and incoming edges.
    #[default]
    Both,
    /// Follow only outgoing edges (source -> target).
    Outgoing,
    /// Follow only incoming edges (target -> source).
    Incoming,
}

/// Filter configuration for BFS traversal.
#[derive(Debug, Clone, Default)]
pub struct TraversalFilter {
    /// Edge types to follow (None = all types).
    pub edge_types: Option<Vec<EdgeType>>,
    /// Whether to include ghost memories in results.
    pub include_ghosts: bool,
    /// Whether to traverse through ghost nodes (even if excluded from results).
    pub traverse_through_ghosts: bool,
    /// Direction: outgoing only, incoming only, or both.
    pub direction: TraversalDirection,
    /// Namespace filter -- only traverse within this namespace.
    pub namespace_id: Option<NamespaceId>,
    /// Maximum results to return (None = unlimited).
    /// BFS terminates early once this count is reached.
    pub max_results: Option<usize>,
}

/// A single result from BFS traversal, carrying the edge that led to
/// this node and the hop distance from the start.
#[derive(Debug, Clone)]
pub struct TraversalResult {
    /// The graph key of the discovered node.
    pub node_key: NodeKey,
    /// The MemoryId of the discovered node.
    pub memory_id: MemoryId,
    /// The edge that connected the previous hop to this node.
    pub edge: GraphEdge,
    /// Number of hops from the start node (1 = direct neighbor).
    pub hop_distance: u8,
}

// ═══════════════════════════════════════════════════════════════════════
// GraphError
// ═══════════════════════════════════════════════════════════════════════

/// Errors returned by graph mutation operations.
#[derive(Debug, thiserror::Error)]
pub enum GraphError {
    /// A memory was not found in the graph.
    #[error("memory {0:?} not found in graph")]
    MemoryNotFound(MemoryId),

    /// A memory already exists in the graph.
    #[error("memory {0:?} already exists in graph")]
    DuplicateNode(MemoryId),

    /// An edge already exists between two memories.
    #[error("edge already exists between {0:?} and {1:?}")]
    EdgeExists(MemoryId, MemoryId),

    /// An edge key was not found.
    #[error("edge key {0:?} not found")]
    EdgeNotFound(EdgeKey),
}

// ═══════════════════════════════════════════════════════════════════════
// GraphStats
// ═══════════════════════════════════════════════════════════════════════

/// Aggregate graph metrics.
#[derive(Debug, Clone)]
pub struct GraphStats {
    /// Total number of nodes.
    pub node_count: usize,
    /// Total number of edges.
    pub edge_count: usize,
    /// Average degree = (2 * edge_count) / node_count.
    /// Each edge contributes to two nodes' degree.
    pub avg_degree: f32,
    /// Maximum degree of any node.
    pub max_degree: usize,
    /// Number of nodes in the Ghost decay phase.
    pub ghost_node_count: usize,
    /// Edge counts broken down by EdgeType.
    pub edges_by_type: HashMap<EdgeType, usize>,
}

// ═══════════════════════════════════════════════════════════════════════
// RemovalResult
// ═══════════════════════════════════════════════════════════════════════

/// Result of a memory removal with bridging.
#[derive(Debug)]
pub struct RemovalResult {
    /// Edges that were removed from the graph (delete from edges.db).
    pub removed_edges: Vec<GraphEdge>,
    /// Bridge edge that was created, if any (persist to edges.db).
    pub bridge_created: Option<GraphEdge>,
}

// ═══════════════════════════════════════════════════════════════════════
// RelationshipGraph
// ═══════════════════════════════════════════════════════════════════════

/// In-memory relationship graph. All nodes and edges are held in
/// generationally-indexed slotmaps for O(1) insert/remove/lookup.
///
/// This struct is wrapped in `Arc<RwLock<RelationshipGraph>>` (the
/// `SharedGraph` alias in mod.rs) for concurrent access.
#[derive(Clone)]
pub struct RelationshipGraph {
    /// Node storage. DenseSlotMap keeps elements contiguous for
    /// cache-friendly iteration during decay sweeps and batch
    /// spreading activation.
    ///
    /// `pub(crate)`: accessed directly by graph operations (CS-11)
    /// for traversal, activation, and batch rebuilds.
    pub(crate) nodes: DenseSlotMap<NodeKey, GraphNode>,

    /// Edge storage. Separate from nodes so edges can be iterated
    /// independently (e.g., for persistence serialization).
    ///
    /// `pub(crate)`: accessed directly by graph operations (CS-11)
    /// for traversal and activation edge lookups.
    pub(crate) edges: DenseSlotMap<EdgeKey, GraphEdge>,

    /// MemoryId -> NodeKey lookup. Every node in `nodes` has exactly
    /// one entry here. This is the primary entry point -- callers
    /// address nodes by MemoryId, not NodeKey.
    ///
    /// `pub(crate)`: accessed directly by graph operations (CS-11)
    /// for key resolution in traversal and auto-linking.
    pub(crate) id_index: HashMap<MemoryId, NodeKey>,
}

// ── Constructor ─────────────────────────────────────────────────────

impl RelationshipGraph {
    /// Create a new empty graph with default capacity.
    ///
    /// Pre-allocates for 1,024 nodes and 4,096 edges. These are
    /// starting sizes -- DenseSlotMap grows automatically.
    pub fn new() -> Self {
        Self {
            nodes: DenseSlotMap::with_capacity_and_key(1_024),
            edges: DenseSlotMap::with_capacity_and_key(4_096),
            id_index: HashMap::with_capacity(1_024),
        }
    }

    /// Create a graph pre-sized for the given node count.
    /// Used at startup when the node count is known from meta.db.
    pub fn with_capacity(node_capacity: usize) -> Self {
        let edge_capacity = node_capacity * 5; // avg degree ~10 -> 5 edges per node
        Self {
            nodes: DenseSlotMap::with_capacity_and_key(node_capacity),
            edges: DenseSlotMap::with_capacity_and_key(edge_capacity),
            id_index: HashMap::with_capacity(node_capacity),
        }
    }
}

impl Default for RelationshipGraph {
    fn default() -> Self {
        Self::new()
    }
}

// ── Node Operations ─────────────────────────────────────────────────

impl RelationshipGraph {
    /// Insert a node for a newly persisted memory.
    ///
    /// Returns the assigned NodeKey. Fails with `DuplicateNode` if a
    /// node for this MemoryId already exists.
    pub fn add_node(
        &mut self,
        memory_id: MemoryId,
        namespace_id: NamespaceId,
        decay_phase: DecayPhase,
        strength: f32,
        vector_slot: u32,
    ) -> Result<NodeKey, GraphError> {
        if self.id_index.contains_key(&memory_id) {
            return Err(GraphError::DuplicateNode(memory_id));
        }

        let node = GraphNode {
            memory_id,
            namespace_id,
            decay_phase,
            strength,
            vector_slot,
            outgoing: Vec::new(),
            incoming: Vec::new(),
        };

        let key = self.nodes.insert(node);
        self.id_index.insert(memory_id, key);
        Ok(key)
    }

    /// Update a node's cached decay state. Called by decay sweeps
    /// after recomputing R(t,S) and checking phase transitions.
    pub fn update_node_state(
        &mut self,
        memory_id: MemoryId,
        decay_phase: DecayPhase,
        strength: f32,
    ) -> Result<(), GraphError> {
        let key = self.resolve_key(memory_id)?;
        let node = self
            .nodes
            .get_mut(key)
            .ok_or(GraphError::MemoryNotFound(memory_id))?;
        node.decay_phase = decay_phase;
        node.strength = strength;
        Ok(())
    }

    /// Check if a memory has a node in the graph.
    #[inline]
    pub fn contains(&self, memory_id: &MemoryId) -> bool {
        self.id_index.contains_key(memory_id)
    }

    /// Get a node's total degree (outgoing + incoming).
    /// Returns 0 if the memory is not in the graph.
    pub fn degree(&self, memory_id: &MemoryId) -> usize {
        self.id_index
            .get(memory_id)
            .and_then(|k| self.nodes.get(*k))
            .map(|n| n.degree())
            .unwrap_or(0)
    }

    /// Total number of nodes in the graph.
    #[inline]
    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }

    /// Read-only access to a node by MemoryId.
    pub fn get_node(&self, memory_id: &MemoryId) -> Option<&GraphNode> {
        self.id_index
            .get(memory_id)
            .and_then(|k| self.nodes.get(*k))
    }

    /// Read-only access to a node by NodeKey.
    pub fn get_node_by_key(&self, key: NodeKey) -> Option<&GraphNode> {
        self.nodes.get(key)
    }
}

// ── Edge Operations ─────────────────────────────────────────────────

impl RelationshipGraph {
    /// Add a directed edge between two memories.
    ///
    /// Returns the assigned EdgeKey. Fails if:
    /// - Either memory is not in the graph (`MemoryNotFound`)
    /// - An edge of the SAME type already exists between them (`EdgeExists`)
    ///
    /// Different edge types between the same pair are allowed (e.g.,
    /// Associative + Entity) because they carry different semantic
    /// meaning and different activation/RIF weights.
    pub fn add_edge(
        &mut self,
        source: MemoryId,
        target: MemoryId,
        edge_type: EdgeType,
        weight: f32,
        auto_created: bool,
    ) -> Result<EdgeKey, GraphError> {
        let source_key = self.resolve_key(source)?;
        let target_key = self.resolve_key(target)?;

        // Check for existing edge of the SAME type (either direction).
        // Different edge types between the same pair are allowed (e.g.,
        // Associative + Entity) because they carry different semantic
        // meaning and different activation/RIF weights.
        if self.has_typed_edge_between(source_key, target_key, edge_type) {
            return Err(GraphError::EdgeExists(source, target));
        }

        let edge = GraphEdge {
            source: source_key,
            target: target_key,
            edge_type,
            weight: weight.clamp(0.0, 1.0),
            auto_created,
            created_at: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_millis() as i64,
        };

        let edge_key = self.edges.insert(edge);

        // Update adjacency lists on both nodes
        self.nodes
            .get_mut(source_key)
            .expect("source validated above")
            .outgoing
            .push(edge_key);
        self.nodes
            .get_mut(target_key)
            .expect("target validated above")
            .incoming
            .push(edge_key);

        Ok(edge_key)
    }

    /// Remove an edge by its key. Returns the removed edge.
    ///
    /// Also removes the edge key from the source's `outgoing` and
    /// the target's `incoming` lists.
    pub fn remove_edge(&mut self, edge_key: EdgeKey) -> Result<GraphEdge, GraphError> {
        let edge = self
            .edges
            .remove(edge_key)
            .ok_or(GraphError::EdgeNotFound(edge_key))?;

        if let Some(src) = self.nodes.get_mut(edge.source) {
            src.outgoing.retain(|k| *k != edge_key);
        }
        if let Some(tgt) = self.nodes.get_mut(edge.target) {
            tgt.incoming.retain(|k| *k != edge_key);
        }

        Ok(edge)
    }

    /// Remove the edge between two memories with a specific type.
    /// Returns true if an edge was found and removed.
    pub fn remove_edge_between(
        &mut self,
        source: MemoryId,
        target: MemoryId,
        edge_type: EdgeType,
    ) -> bool {
        let (source_key, target_key) = match (
            self.id_index.get(&source).copied(),
            self.id_index.get(&target).copied(),
        ) {
            (Some(s), Some(t)) => (s, t),
            _ => return false,
        };

        // Find the edge key in source's outgoing list
        let edge_key = self.nodes.get(source_key).and_then(|node| {
            node.outgoing
                .iter()
                .find(|&&ek| {
                    self.edges
                        .get(ek)
                        .is_some_and(|e| e.target == target_key && e.edge_type == edge_type)
                })
                .copied()
        });

        match edge_key {
            Some(ek) => self.remove_edge(ek).is_ok(),
            None => false,
        }
    }

    /// List all edges connected to a memory (both outgoing and incoming).
    pub fn edges_for(&self, memory_id: &MemoryId) -> Vec<&GraphEdge> {
        let Some(&key) = self.id_index.get(memory_id) else {
            return Vec::new();
        };
        let Some(node) = self.nodes.get(key) else {
            return Vec::new();
        };

        node.outgoing
            .iter()
            .chain(node.incoming.iter())
            .filter_map(|ek| self.edges.get(*ek))
            .collect()
    }

    /// Outgoing edges only (this memory is source).
    pub fn outgoing_edges(&self, memory_id: &MemoryId) -> Vec<&GraphEdge> {
        let Some(&key) = self.id_index.get(memory_id) else {
            return Vec::new();
        };
        let Some(node) = self.nodes.get(key) else {
            return Vec::new();
        };
        node.outgoing
            .iter()
            .filter_map(|ek| self.edges.get(*ek))
            .collect()
    }

    /// Incoming edges only (this memory is target).
    pub fn incoming_edges(&self, memory_id: &MemoryId) -> Vec<&GraphEdge> {
        let Some(&key) = self.id_index.get(memory_id) else {
            return Vec::new();
        };
        let Some(node) = self.nodes.get(key) else {
            return Vec::new();
        };
        node.incoming
            .iter()
            .filter_map(|ek| self.edges.get(*ek))
            .collect()
    }

    /// Total number of edges in the graph.
    #[inline]
    pub fn edge_count(&self) -> usize {
        self.edges.len()
    }

    /// Follow incoming `Supersedes` edges to the newest version of `id`.
    ///
    /// A `Supersedes` edge runs source (new) -> target (old), so the memory
    /// that replaces `id` is the *source* of an incoming edge. The walk
    /// repeats until it reaches a memory nothing supersedes.
    ///
    /// Returns `None` when `id` is already current, and also when the chain
    /// contains a cycle. A cycle has no newest version, so substituting an
    /// arbitrary node from inside it would make recall return a different
    /// memory depending on hash iteration order; returning the original
    /// memory unchanged is the only stable answer.
    pub fn supersedes_terminal(&self, id: &MemoryId) -> Option<MemoryId> {
        /// Hop ceiling, a second guard behind the cycle check. Real
        /// correction chains are a handful of links at most.
        const MAX_HOPS: usize = 10;

        let mut visited: std::collections::HashSet<MemoryId> = std::collections::HashSet::new();
        visited.insert(*id);

        let mut current = *id;
        for _ in 0..MAX_HOPS {
            let replacement = self.incoming_edges(&current).into_iter().find_map(|edge| {
                if edge.edge_type == EdgeType::Supersedes {
                    self.nodes.get(edge.source).map(|n| n.memory_id)
                } else {
                    None
                }
            });

            match replacement {
                // Revisiting a node means the chain loops.
                Some(next) if !visited.insert(next) => return None,
                Some(next) => current = next,
                None => break,
            }
        }

        if current == *id { None } else { Some(current) }
    }

    /// Read-only access to an edge by key.
    pub fn get_edge(&self, key: EdgeKey) -> Option<&GraphEdge> {
        self.edges.get(key)
    }
}

// ── Statistics ───────────────────────────────────────────────────────

impl RelationshipGraph {
    /// Compute graph-wide statistics for monitoring and debugging.
    pub fn stats(&self) -> GraphStats {
        let node_count = self.nodes.len();
        let edge_count = self.edges.len();

        let mut max_degree: usize = 0;
        let mut ghost_count: usize = 0;
        let mut edges_by_type: HashMap<EdgeType, usize> = HashMap::new();

        for (_, node) in &self.nodes {
            let d = node.degree();
            if d > max_degree {
                max_degree = d;
            }
            if node.decay_phase == DecayPhase::Ghost {
                ghost_count += 1;
            }
        }

        for (_, edge) in &self.edges {
            *edges_by_type.entry(edge.edge_type).or_insert(0) += 1;
        }

        let avg_degree = if node_count > 0 {
            (edge_count as f32 * 2.0) / node_count as f32
        } else {
            0.0
        };

        GraphStats {
            node_count,
            edge_count,
            avg_degree,
            max_degree,
            ghost_node_count: ghost_count,
            edges_by_type,
        }
    }
}

// ── Ghost Bridging ──────────────────────────────────────────────────

impl RelationshipGraph {
    /// Remove a ghost memory and handle its edges with pass-through bridging.
    ///
    /// Returns a `RemovalResult` containing removed edges (caller must
    /// delete from edges.db) and any bridge edge created (caller must
    /// persist to edges.db).
    ///
    /// # Bridge creation
    /// Only creates a bridge for pass-through nodes (1 in, 1 out, same
    /// edge type). Bridge weight = w_in * w_out * 0.9, minimum 0.1.
    pub fn remove_memory_with_bridging(&mut self, memory_id: MemoryId) -> RemovalResult {
        let Some(&node_key) = self.id_index.get(&memory_id) else {
            return RemovalResult {
                removed_edges: Vec::new(),
                bridge_created: None,
            };
        };
        let Some(node) = self.nodes.get(node_key) else {
            // Same stale-index case as `remove_memory`: the entry has to
            // go, or `contains` keeps claiming the memory is here.
            tracing::warn!(
                memory_id = %memory_id,
                "Graph id_index named a node that does not exist; dropping the stale entry"
            );
            self.id_index.remove(&memory_id);
            return RemovalResult {
                removed_edges: Vec::new(),
                bridge_created: None,
            };
        };

        let in_degree = node.incoming.len();
        let out_degree = node.outgoing.len();
        let mut bridge_created: Option<GraphEdge> = None;

        // Tier 2: Pass-through node (1 in, 1 out, same edge type) -- bridge
        let should_bridge = in_degree == 1 && out_degree == 1 && {
            let in_edge = self.edges.get(node.incoming[0]);
            let out_edge = self.edges.get(node.outgoing[0]);
            match (in_edge, out_edge) {
                (Some(ie), Some(oe)) => ie.edge_type == oe.edge_type,
                _ => false,
            }
        };

        if should_bridge {
            if let (Some(in_edge), Some(out_edge)) = (
                self.edges.get(node.incoming[0]).cloned(),
                self.edges.get(node.outgoing[0]).cloned(),
            ) {
                let bridge_weight = in_edge.weight * out_edge.weight * 0.9;
                let predecessor = in_edge.source;
                let successor = out_edge.target;

                // Only bridge if no edge of the same type already exists (either direction)
                // and weight is sufficient
                let edge_exists =
                    self.has_typed_edge_between(predecessor, successor, in_edge.edge_type);

                if !edge_exists && bridge_weight > 0.1 {
                    let bridge = GraphEdge {
                        source: predecessor,
                        target: successor,
                        edge_type: in_edge.edge_type,
                        weight: bridge_weight,
                        auto_created: true,
                        created_at: std::time::SystemTime::now()
                            .duration_since(std::time::UNIX_EPOCH)
                            .unwrap_or_default()
                            .as_millis() as i64,
                    };

                    let ek = self.edges.insert(bridge.clone());
                    if let Some(pred_node) = self.nodes.get_mut(predecessor) {
                        pred_node.outgoing.push(ek);
                    }
                    if let Some(succ_node) = self.nodes.get_mut(successor) {
                        succ_node.incoming.push(ek);
                    }
                    bridge_created = Some(bridge);
                }
            }
        }

        // Remove the node and its edges. Re-resolves the node key,
        // since the bridge above may have mutated other nodes.
        let removed_edges = self.remove_memory(memory_id);

        RemovalResult {
            removed_edges,
            bridge_created,
        }
    }

    /// Remove a memory's node and every edge incident to it, creating
    /// no bridge. Returns the removed edges so the caller can delete
    /// them from edges.db.
    ///
    /// Returns an empty vec if the memory has no node.
    ///
    /// # When to use this instead of bridging
    ///
    /// Use it when the memory is going away because its whole
    /// **namespace** is going away. Bridging exists to preserve a chain
    /// through a memory that decayed out from under it — the
    /// relationship was real and only the waypoint is gone. In a
    /// namespace deletion the relationship is exactly what the user
    /// asked to erase, so manufacturing a new edge between two survivors
    /// on the strength of it would resurrect, in summary form, the thing
    /// that was just destroyed.
    pub fn remove_memory(&mut self, memory_id: MemoryId) -> Vec<GraphEdge> {
        let Some(&node_key) = self.id_index.get(&memory_id) else {
            return Vec::new();
        };
        let Some(node) = self.nodes.get(node_key) else {
            // An id_index key whose node is gone. Bailing out left the
            // stale entry in place forever, so `contains` went on saying
            // the memory was in the graph and every later removal took
            // this same branch and did nothing. Removing it is the whole
            // job that is left to do.
            tracing::warn!(
                memory_id = %memory_id,
                "Graph id_index named a node that does not exist; dropping the stale entry"
            );
            self.id_index.remove(&memory_id);
            return Vec::new();
        };

        let all_edge_keys: Vec<EdgeKey> = node
            .outgoing
            .iter()
            .chain(node.incoming.iter())
            .copied()
            .collect();

        let mut removed_edges = Vec::with_capacity(all_edge_keys.len());

        for ek in all_edge_keys {
            if let Some(edge) = self.edges.remove(ek) {
                // Remove from the other node's edge lists
                let other_key = if edge.source == node_key {
                    edge.target
                } else {
                    edge.source
                };
                if let Some(other_node) = self.nodes.get_mut(other_key) {
                    other_node.outgoing.retain(|e| *e != ek);
                    other_node.incoming.retain(|e| *e != ek);
                }
                removed_edges.push(edge);
            }
        }

        // Remove the node itself
        self.nodes.remove(node_key);
        self.id_index.remove(&memory_id);

        removed_edges
    }
}

// ── Internal Helpers ────────────────────────────────────────────────

impl RelationshipGraph {
    /// Resolve a MemoryId to its NodeKey, or error.
    fn resolve_key(&self, memory_id: MemoryId) -> Result<NodeKey, GraphError> {
        self.id_index
            .get(&memory_id)
            .copied()
            .ok_or(GraphError::MemoryNotFound(memory_id))
    }

    /// Check if an edge of a specific type exists between two node keys (either direction).
    pub(crate) fn has_typed_edge_between(
        &self,
        a: NodeKey,
        b: NodeKey,
        edge_type: EdgeType,
    ) -> bool {
        if let Some(node_a) = self.nodes.get(a) {
            // Check a's outgoing for edges targeting b with matching type
            for &ek in &node_a.outgoing {
                if let Some(edge) = self.edges.get(ek) {
                    if edge.target == b && edge.edge_type == edge_type {
                        return true;
                    }
                }
            }
            // Also check a's incoming (covers b->a direction)
            for &ek in &node_a.incoming {
                if let Some(edge) = self.edges.get(ek) {
                    if edge.source == b && edge.edge_type == edge_type {
                        return true;
                    }
                }
            }
        }
        false
    }

    /// Check if an edge of a specific type exists between two memories (either direction).
    ///
    /// Convenience wrapper around `has_typed_edge_between` that resolves
    /// `MemoryId`s to `NodeKey`s first. Returns `false` if either memory
    /// is not present in the graph.
    pub(crate) fn has_typed_edge_between_ids(
        &self,
        a: &MemoryId,
        b: &MemoryId,
        edge_type: EdgeType,
    ) -> bool {
        let Some(&a_key) = self.id_index.get(a) else {
            return false;
        };
        let Some(&b_key) = self.id_index.get(b) else {
            return false;
        };
        self.has_typed_edge_between(a_key, b_key, edge_type)
    }

    /// Provide read-only access to the node slotmap for iteration.
    /// Used by CS-11 (spreading activation batch sweep) and CS-04
    /// (decay sweep runner).
    pub fn iter_nodes(&self) -> impl Iterator<Item = (NodeKey, &GraphNode)> {
        self.nodes.iter()
    }

    /// Provide read-only access to the edge slotmap for iteration.
    /// Used by persistence serialization (all_edges).
    pub fn iter_edges(&self) -> impl Iterator<Item = (EdgeKey, &GraphEdge)> {
        self.edges.iter()
    }

    /// Look up a NodeKey by MemoryId. Public for CS-11 operations
    /// that need to work with keys directly.
    pub fn resolve(&self, memory_id: &MemoryId) -> Option<NodeKey> {
        self.id_index.get(memory_id).copied()
    }
}

// ═══════════════════════════════════════════════════════════════════════
// Tests
// ═══════════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    /// Build a graph holding `n` fresh Full-phase nodes in one namespace.
    fn graph_with_nodes(n: usize) -> (RelationshipGraph, Vec<MemoryId>) {
        let mut graph = RelationshipGraph::new();
        let ns = NamespaceId::new(1);
        let ids: Vec<MemoryId> = (0..n).map(|_| MemoryId::new()).collect();
        for id in &ids {
            graph
                .add_node(*id, ns, DecayPhase::Full, 1.0, 0)
                .expect("fresh id");
        }
        (graph, ids)
    }

    /// A stale `id_index` entry — a key whose `nodes` slot is gone —
    /// used to make both removal paths bail out WITHOUT dropping it. So
    /// `contains` went on reporting the memory as present, every later
    /// removal took the same branch and did nothing, and the entry
    /// outlived the process.
    #[test]
    fn w72_removal_drops_an_id_index_entry_whose_node_is_gone() {
        for with_bridging in [false, true] {
            let (mut graph, ids) = graph_with_nodes(1);
            let id = ids[0];

            // Remove the node behind the index's back.
            let key = *graph.id_index.get(&id).expect("indexed");
            graph.nodes.remove(key);
            assert!(
                graph.contains(&id),
                "the setup did not create a stale entry"
            );

            if with_bridging {
                graph.remove_memory_with_bridging(id);
            } else {
                graph.remove_memory(id);
            }

            assert!(
                !graph.contains(&id),
                "with_bridging={with_bridging}: the stale id_index entry survived"
            );
        }
    }

    /// Add a Supersedes edge meaning "`new` replaces `old`".
    fn supersede(
        graph: &mut RelationshipGraph,
        new: MemoryId,
        old: MemoryId,
    ) -> Result<EdgeKey, GraphError> {
        graph.add_edge(new, old, EdgeType::Supersedes, 1.0, false)
    }

    /// An edge to a memory that is not in the graph is refused, which is
    /// what makes pre-validating the target worth doing.
    #[test]
    fn supersedes_edge_to_missing_target_errors() {
        let (mut graph, ids) = graph_with_nodes(1);
        let missing = MemoryId::new();

        let err = supersede(&mut graph, ids[0], missing).unwrap_err();

        assert!(matches!(err, GraphError::MemoryNotFound(id) if id == missing));
        assert_eq!(graph.edge_count(), 0);
    }

    /// The exact edge shape `supersedes_terminal` depends on: the new
    /// memory is the SOURCE of an edge incoming to the old one.
    #[test]
    fn valid_target_creates_edge_with_new_memory_as_source() {
        let (mut graph, ids) = graph_with_nodes(2);
        let (new, old) = (ids[0], ids[1]);

        supersede(&mut graph, new, old).expect("both nodes present");

        let incoming = graph.incoming_edges(&old);
        assert_eq!(incoming.len(), 1);
        assert_eq!(incoming[0].edge_type, EdgeType::Supersedes);
        assert_eq!(
            graph.nodes.get(incoming[0].source).map(|n| n.memory_id),
            Some(new)
        );
    }

    /// Storing the same correction twice is idempotent at the graph level.
    /// The store path reports this as `alreadyApplied`, not as an error:
    /// supersedes is a desired end state, and the end state is in place.
    #[test]
    fn duplicate_supersedes_edge_is_rejected_as_already_existing() {
        let (mut graph, ids) = graph_with_nodes(2);
        let (new, old) = (ids[0], ids[1]);

        supersede(&mut graph, new, old).expect("first insert");
        let err = supersede(&mut graph, new, old).unwrap_err();

        assert!(matches!(err, GraphError::EdgeExists(_, _)));
        assert_eq!(graph.edge_count(), 1);
    }

    /// A chain of corrections resolves to its newest member, not to the
    /// first hop.
    #[test]
    fn supersedes_terminal_follows_the_chain_to_the_newest_version() {
        let (mut graph, ids) = graph_with_nodes(3);
        let (a, b, c) = (ids[0], ids[1], ids[2]);

        supersede(&mut graph, a, b).expect("a replaces b");
        supersede(&mut graph, c, a).expect("c replaces a");

        assert_eq!(graph.supersedes_terminal(&b), Some(c));
        assert_eq!(graph.supersedes_terminal(&a), Some(c));
    }

    /// A memory nothing has replaced resolves to nothing, so recall leaves
    /// it alone.
    #[test]
    fn supersedes_terminal_is_none_for_a_current_memory() {
        let (mut graph, ids) = graph_with_nodes(2);
        supersede(&mut graph, ids[0], ids[1]).expect("a replaces b");

        assert_eq!(graph.supersedes_terminal(&ids[0]), None);
    }

    /// Regression guard for the cycle detection. A two-node cycle cannot be
    /// built through `add_edge` (its duplicate check spans both directions)
    /// but `rebuild_from_storage` inserts edges.db rows without that check,
    /// so a restart can materialise one. Before cycle detection this walked
    /// the full hop cap and substituted whichever node it happened to land
    /// on; now it terminates with "no newest version".
    #[test]
    fn supersedes_terminal_returns_none_on_a_cycle() {
        let (mut graph, ids) = graph_with_nodes(2);
        let (a, b) = (ids[0], ids[1]);

        let edge = |source, target| crate::storage::PersistedEdge {
            source,
            target,
            edge_type: EdgeType::Supersedes,
            weight: 1.0,
            auto_created: false,
            created_at: 0,
        };
        let loaded =
            crate::graph::rebuild_from_storage(&mut graph, [edge(a, b), edge(b, a)].into_iter());
        assert_eq!(loaded, 2);

        assert_eq!(graph.supersedes_terminal(&a), None);
        assert_eq!(graph.supersedes_terminal(&b), None);
    }

    /// A longer cycle terminates too, and reports the same "no answer".
    #[test]
    fn supersedes_terminal_returns_none_on_a_three_node_cycle() {
        let (mut graph, ids) = graph_with_nodes(3);
        let (a, b, c) = (ids[0], ids[1], ids[2]);

        supersede(&mut graph, a, b).expect("a replaces b");
        supersede(&mut graph, b, c).expect("b replaces c");
        supersede(&mut graph, c, a).expect("c replaces a");

        assert_eq!(graph.supersedes_terminal(&a), None);
        assert_eq!(graph.supersedes_terminal(&b), None);
        assert_eq!(graph.supersedes_terminal(&c), None);
    }

    /// The same shape `remove_memory_with_bridging` bridges across — one
    /// in, one out, matching type — must produce no bridge here. A
    /// namespace deletion erases the relationship, so inventing a new
    /// edge between two survivors on the strength of it would resurrect
    /// in summary form the thing that was just destroyed.
    #[test]
    fn w23_remove_memory_removes_the_node_and_its_edges_without_bridging() {
        /// A pass-through shape: predecessor -> middle -> successor, one
        /// in, one out, same edge type.
        fn pass_through() -> (RelationshipGraph, MemoryId, MemoryId, MemoryId) {
            let (mut graph, ids) = graph_with_nodes(3);
            graph
                .add_edge(ids[0], ids[1], EdgeType::Associative, 1.0, false)
                .expect("in edge");
            graph
                .add_edge(ids[1], ids[2], EdgeType::Associative, 1.0, false)
                .expect("out edge");
            (graph, ids[0], ids[1], ids[2])
        }

        // Establish that this shape really is one bridging would bridge,
        // so the assertion below is about the new path and not about an
        // input that would never have bridged anyway.
        let (mut bridging, _, middle, _) = pass_through();
        assert!(
            bridging
                .remove_memory_with_bridging(middle)
                .bridge_created
                .is_some(),
            "the shape under test is not one that bridging would bridge"
        );

        let (mut graph, predecessor, middle, successor) = pass_through();
        let removed = graph.remove_memory(middle);

        assert_eq!(removed.len(), 2);
        assert!(!graph.contains(&middle));
        assert_eq!(graph.edge_count(), 0, "a bridge edge was manufactured");
        assert_eq!(graph.degree(&predecessor), 0);
        assert_eq!(graph.degree(&successor), 0);
        assert!(graph.contains(&predecessor) && graph.contains(&successor));
    }

    #[test]
    fn w23b_remove_memory_of_an_unknown_id_is_empty() {
        let (mut graph, _) = graph_with_nodes(1);
        assert!(graph.remove_memory(MemoryId::new()).is_empty());
    }
}
