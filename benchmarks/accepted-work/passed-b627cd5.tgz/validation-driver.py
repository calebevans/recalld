"""Explicitly invoked only AFTER the user's A5 measurement release."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
SOURCE = Path('/tmp/recalld-implementation/accepted-work')
HARNESS = Path('/tmp/recalld-implementation/observed-consumer-evidence/scripts/public-conformance.py')
IMAGE = 'sha256:daefdc9cbe9b0f39b1fc29d975148b3b10adc1bd4309f9ca1be8abd36ed811ef'
spec = importlib.util.spec_from_file_location('public_runner', HARNESS)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
mode = sys.argv[1]
assert mode in ('format', 'test')
root = Path(tempfile.mkdtemp(prefix=f'recalld-accepted-{mode}-', dir='/tmp'))
out = root / 'output'
out.mkdir()
commit = runner.git(SOURCE, 'rev-parse', 'HEAD').decode().strip()
provenance, patch = runner.snapshot(SOURCE, root / 'source', expected_commit=commit if mode == 'test' else None)
(out / 'source.patch').write_bytes(patch)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
manifest = {'track': 'accepted-work-core', 'status': 'preparing', 'mode': mode,
            **provenance, 'imageId': IMAGE, 'harnessSha256': sha(HARNESS),
            'driverSha256': sha(Path(__file__)), 'dirtyPatchSha256': sha(out / 'source.patch')}
if mode == 'test':
    cache = Path(sys.argv[2])
    assert cache.is_relative_to('/tmp') and cache.name == 'target'
    shutil.copytree('/tmp/recalld-unit-tests-l__ja1yo/cargo/registry', root / 'cargo/registry')
    shutil.copytree(cache, root / 'target')
    script = '''set -eu
mkdir -p /tmp/home
rustc -Vv > /work/output/rustc.txt
cat /sys/fs/cgroup/cpu.max > /work/output/cgroup-cpu.txt
cat /sys/fs/cgroup/memory.max > /work/output/cgroup-memory.txt
cargo fmt --all --check > /work/output/fmt.log 2>&1
cargo test --offline --locked --all-features --lib work::tests -j1 -- --nocapture > /work/output/work-tests.log 2>&1
cargo test --offline --locked --all-features --lib derived_completion::tests -j1 -- --nocapture > /work/output/completion-tests.log 2>&1
cargo test --offline --locked --all-features --lib --bins --tests --examples -j1 > /work/output/full-tests.log 2>&1
cargo clippy --offline --locked --all-features --all-targets > /work/output/clippy.log 2>&1
'''
else:
    script = 'cargo fmt --all > /work/output/format.log 2>&1'
command = ['docker', 'run', '--rm', '--network', 'none', '--cpus', '2', '--memory', '4g',
           '--memory-swap', '4g', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
           '--read-only', '--tmpfs', '/tmp:rw,nosuid,nodev',
           '--mount', f'type=bind,src={root},dst=/work',
           '-w', '/work/source', '-e', 'HOME=/tmp/home', '-e', 'RUSTUP_TOOLCHAIN=1.94.1',
           '-e', 'CARGO_HOME=/work/cargo', '-e', 'CARGO_TARGET_DIR=/work/target',
           '-e', 'CARGO_BUILD_JOBS=2', '-e', 'CARGO_NET_OFFLINE=true']
if mode == 'test':
    command += ['--mount', f'type=bind,src={root}/source,dst=/work/source,readonly']
command += [IMAGE, 'sh', '-c', script]
manifest['command'] = command
runner.save(out / 'manifest.json', manifest)
print(root, flush=True)
result = subprocess.run(command)
manifest['exitCode'] = result.returncode
manifest['status'] = 'passed' if result.returncode == 0 else 'failed'
manifest['outputsSha256'] = {p.name: sha(p) for p in out.iterdir() if p.name != 'manifest.json'}
runner.save(out / 'manifest.json', manifest)
if mode == 'format' and result.returncode == 0:
    changed = set(runner.git(SOURCE, 'diff', 'HEAD', '--name-only').decode().splitlines())
    for name, before in provenance['sourceFilesSha256'].items():
        if name.endswith('.rs') and sha(root / 'source' / name) != before:
            assert name in changed, f'formatter changed unrelated source: {name}'
            assert sha(SOURCE / name) == before, f'source changed during format: {name}'
            shutil.copyfile(root / 'source' / name, SOURCE / name)
elif mode == 'test':
    for name, expected in provenance['sourceFilesSha256'].items():
        assert sha(root / 'source' / name) == expected, name
print(json.dumps({'root': str(root), 'status': manifest['status'], 'exitCode': result.returncode}), flush=True)
sys.exit(result.returncode)
